% README for FVCOM_postproc
%
% This directory contains matlab scripts for postrpocessing FVCOM output
%
% Author(s):  
%
% Revision history
%   
%==============================================================================
