% Time to sort out this volume calculation. 

% For a given concentration going in (say 500 mmol/s), then the total
% amount enetered into the system will be less because it'll be spread over
% the volume of the TCE. So, 